# Signal Forge Edge Lab

A more selective, experimental crypto spot bot plus a historical backtest script. It is not a profit guarantee.

## Included
- Regime filter: price/EMA trend alignment.
- Breakout + RSI + directional-movement/trend-strength confirmation.
- ATR-based initial and trailing stop logic.
- Fee/slippage assumptions in backtest and paper simulation.
- Paper mode by default; cloud Docker restart policy.

## Run on a Docker-capable Linux VPS
1. Copy `.env.example` to `.env` and keep `PAPER=true`.
2. Run `docker compose up -d --build`.
3. Logs: `docker compose logs -f`.
4. Stop: `docker compose down`.

## Backtest
Install requirements, then run:
`python backtest.py --symbol BTC/USDT --timeframe 15m --days 180 --fee 0.001 --slippage 0.0005`

Run several market windows and symbols, then reserve a later period as out-of-sample data. A profitable historical result does not establish a future edge. Inspect trade count, max drawdown, fee sensitivity and bull/bear/sideways performance.

## Safety
PAPER=true by default. Live mode requires an exchange key/secret stored only on the server. Use trade-only permissions, disable withdrawals and IP-restrict the key. Software stops cannot execute during outages. Live execution and exchange-specific order handling need careful validation. No leverage is used. This is experimental software, not investment advice or a guaranteed-profit system.
