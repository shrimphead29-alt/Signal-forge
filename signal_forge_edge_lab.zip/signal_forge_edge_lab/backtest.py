import argparse
import ccxt
import pandas as pd
import numpy as np

def calc(df):
    c,h,l = df.close,df.high,df.low
    df["ema50"]=c.ewm(span=50,adjust=False).mean()
    df["ema200"]=c.ewm(span=200,adjust=False).mean()
    d=c.diff()
    g=d.clip(lower=0).ewm(alpha=1/14,adjust=False).mean()
    loss=(-d.clip(upper=0)).ewm(alpha=1/14,adjust=False).mean()
    df["rsi"]=100-100/(1+g/loss.replace(0,np.nan))
    pc=c.shift(1)
    tr=pd.concat([h-l,(h-pc).abs(),(l-pc).abs()],axis=1).max(axis=1)
    df["atr"]=tr.ewm(alpha=1/14,adjust=False).mean()
    up,down=h.diff(),-l.diff()
    pdm=up.where((up>down)&(up>0),0.0); mdm=down.where((down>up)&(down>0),0.0)
    pdi=100*pdm.ewm(alpha=1/14,adjust=False).mean()/df.atr
    mdi=100*mdm.ewm(alpha=1/14,adjust=False).mean()/df.atr
    dx=100*(pdi-mdi).abs()/(pdi+mdi).replace(0,np.nan)
    df["adx"]=dx.ewm(alpha=1/14,adjust=False).mean()
    df["pdi"],df["mdi"]=pdi,mdi
    df["prior_high"]=h.shift(1).rolling(20).max()
    return df.dropna()

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--symbol",default="BTC/USDT")
    p.add_argument("--timeframe",default="15m")
    p.add_argument("--days",type=int,default=180)
    p.add_argument("--fee",type=float,default=0.001)
    p.add_argument("--slippage",type=float,default=0.0005)
    p.add_argument("--quote",type=float,default=20)
    a=p.parse_args()
    ex=ccxt.binance({"enableRateLimit":True})
    since=ex.milliseconds()-a.days*24*60*60*1000
    rows=[]
    while since < ex.milliseconds():
        chunk=ex.fetch_ohlcv(a.symbol,timeframe=a.timeframe,since=since,limit=1000)
        if not chunk: break
        rows.extend(chunk); since=chunk[-1][0]+1
        if len(chunk)<2: break
    df=pd.DataFrame(rows,columns=["ts","open","high","low","close","volume"]).drop_duplicates("ts").sort_values("ts")
    df=calc(df.reset_index(drop=True))
    cash=1000.0; equity=1000.0; peak=equity; maxdd=0.0; pos=None; trades=[]
    for i in range(1,len(df)):
        prev,r=df.iloc[i-1],df.iloc[i]
        px=float(r.open) # conservative next-candle open execution
        if pos:
            pos["stop"]=max(pos["stop"],float(r.close)-2.5*float(r.atr))
            exit_it=float(r.low)<=pos["stop"] or float(r.close)<float(r.ema50) or float(r.rsi)<42
            if exit_it:
                # If stop crossed, assume stop price; otherwise close; apply slippage and fees.
                raw=min(pos["stop"],float(r.close)) if float(r.low)<=pos["stop"] else float(r.close)
                fill=raw*(1-a.slippage)
                proceeds=pos["qty"]*fill*(1-a.fee)
                pnl=proceeds-pos["cost"]
                cash+=proceeds
                trades.append(pnl); pos=None
        else:
            cond=(float(r.close)>float(r.ema200) and float(r.ema50)>float(r.ema200)
                and float(r.close)>float(r.prior_high) and 52<=float(r.rsi)<=68
                and float(r.pdi)>float(r.mdi) and float(r.adx)>=18)
            if cond and cash>10:
                notional=min(a.quote,cash)
                fill=px*(1+a.slippage)
                qty=notional/fill
                cost=notional*(1+a.fee)
                if cost<=cash:
                    cash-=cost
                    pos={"qty":qty,"cost":cost,"stop":fill-2*float(r.atr)}
        equity=cash+(pos["qty"]*float(r.close) if pos else 0)
        peak=max(peak,equity); maxdd=max(maxdd,(peak-equity)/peak)
    if pos:
        r=df.iloc[-1]; fill=float(r.close)*(1-a.slippage)
        proceeds=pos["qty"]*fill*(1-a.fee); trades.append(proceeds-pos["cost"]); cash+=proceeds
        equity=cash
    total_return=(equity/1000-1)*100
    wins=sum(1 for x in trades if x>0)
    print(f"Symbol: {a.symbol} | timeframe: {a.timeframe} | candles: {len(df)} | days requested: {a.days}")
    print(f"Starting equity: 1000.00 | Ending equity: {equity:.2f} | Return: {total_return:.2f}%")
    print(f"Closed trades: {len(trades)} | Win rate: {wins/len(trades)*100:.1f}%" if trades else "Closed trades: 0 | Win rate: n/a")
    print(f"Max drawdown (approx): {maxdd*100:.2f}% | Fees: {a.fee*100:.3f}% each side | Slippage: {a.slippage*100:.3f}% each side")
    print("WARNING: exploratory backtest only; no out-of-sample validation, no funding/tax effects, and fills are approximations.")
if __name__=="__main__": main()
