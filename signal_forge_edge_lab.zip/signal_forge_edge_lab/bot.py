import os, time, json, logging
from datetime import datetime, timezone
import ccxt
import pandas as pd

# Signal Forge Edge Lab. Paper mode is the default.
EXCHANGE_ID = os.getenv("EXCHANGE_ID", "binance")
SYMBOL = os.getenv("SYMBOL", "BTC/USDT")
TIMEFRAME = os.getenv("TIMEFRAME", "15m")
PAPER = os.getenv("PAPER", "true").lower() == "true"
API_KEY, API_SECRET = os.getenv("EXCHANGE_API_KEY", ""), os.getenv("EXCHANGE_API_SECRET", "")
QUOTE_PER_TRADE = float(os.getenv("QUOTE_PER_TRADE", "20"))
MAX_POSITION_QUOTE = float(os.getenv("MAX_POSITION_QUOTE", "40"))
RISK_FRACTION = float(os.getenv("RISK_FRACTION", "0.20"))
MAX_DAILY_LOSS_QUOTE = float(os.getenv("MAX_DAILY_LOSS_QUOTE", "5"))
FEE_RATE = float(os.getenv("FEE_RATE", "0.001"))
SLIPPAGE_RATE = float(os.getenv("SLIPPAGE_RATE", "0.0005"))
POLL_SECONDS = int(os.getenv("POLL_SECONDS", "20"))
STATE_FILE = os.getenv("STATE_FILE", "data/state.json")

logging.basicConfig(level=logging.INFO, format="%(asctime)s UTC %(levelname)s %(message)s")
log = logging.getLogger("signal-forge")

def now():
    return datetime.now(timezone.utc)

def load_state():
    try:
        with open(STATE_FILE) as f: return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {"position": None, "day": now().date().isoformat(), "daily_pnl": 0.0, "last_candle": None}

def save_state(s):
    os.makedirs(os.path.dirname(STATE_FILE) or ".", exist_ok=True)
    tmp = STATE_FILE + ".tmp"
    with open(tmp, "w") as f: json.dump(s, f, indent=2)
    os.replace(tmp, STATE_FILE)

def indicators(df):
    c, h, l = df["close"], df["high"], df["low"]
    df["ema20"] = c.ewm(span=20, adjust=False).mean()
    df["ema50"] = c.ewm(span=50, adjust=False).mean()
    df["ema200"] = c.ewm(span=200, adjust=False).mean()
    delta = c.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/14, adjust=False).mean()
    rs = gain / loss.replace(0, float("nan"))
    df["rsi"] = 100 - 100/(1+rs)
    prev_close = c.shift(1)
    tr = pd.concat([(h-l), (h-prev_close).abs(), (l-prev_close).abs()], axis=1).max(axis=1)
    df["atr"] = tr.ewm(alpha=1/14, adjust=False).mean()
    # Directional movement / ADX-style trend-strength filter
    up, down = h.diff(), -l.diff()
    plus_dm = up.where((up > down) & (up > 0), 0.0)
    minus_dm = down.where((down > up) & (down > 0), 0.0)
    atr = df["atr"].replace(0, float("nan"))
    plus_di = 100 * plus_dm.ewm(alpha=1/14, adjust=False).mean() / atr
    minus_di = 100 * minus_dm.ewm(alpha=1/14, adjust=False).mean() / atr
    dx = 100 * (plus_di-minus_di).abs() / (plus_di+minus_di).replace(0, float("nan"))
    df["adx"] = dx.ewm(alpha=1/14, adjust=False).mean()
    df["plus_di"], df["minus_di"] = plus_di, minus_di
    # Recent range breakout, excluding current candle
    df["prior_high"] = h.shift(1).rolling(20).max()
    return df

def make_exchange():
    ex = getattr(ccxt, EXCHANGE_ID)({"enableRateLimit": True, "timeout": 20000,
        **({"apiKey": API_KEY, "secret": API_SECRET} if API_KEY and API_SECRET else {})})
    return ex

def main():
    state = load_state()
    ex = make_exchange()
    ex.load_markets()
    if SYMBOL not in ex.markets: raise RuntimeError(f"Unsupported market: {SYMBOL}")
    log.info("Started | %s %s | PAPER=%s | this strategy is experimental, not proven profitable", EXCHANGE_ID, SYMBOL, PAPER)
    while True:
        try:
            today = now().date().isoformat()
            if state["day"] != today:
                state["day"], state["daily_pnl"] = today, 0.0
                save_state(state)
            raw = ex.fetch_ohlcv(SYMBOL, timeframe=TIMEFRAME, limit=350)
            df = pd.DataFrame(raw, columns=["ts","open","high","low","close","volume"])
            df = indicators(df.iloc[:-1].copy()).dropna()
            if len(df) < 5:
                time.sleep(POLL_SECONDS); continue
            r = df.iloc[-1]
            candle_id = int(r.ts)
            if state.get("last_candle") == candle_id:
                time.sleep(POLL_SECONDS); continue
            price, atr = float(r.close), float(r.atr)
            pos = state.get("position")
            if state["daily_pnl"] <= -abs(MAX_DAILY_LOSS_QUOTE):
                log.warning("Daily loss limit reached; entries disabled until UTC day resets.")
            elif pos:
                entry, qty = float(pos["entry"]), float(pos["qty"])
                stop = float(pos["stop"])
                # Trail stop only upward, never loosen it.
                new_trail = price - 2.5 * atr
                pos["stop"] = max(stop, new_trail)
                exit_reason = "trailing_stop" if price <= pos["stop"] else (
                    "trend_break" if price < float(r.ema50) or float(r.rsi) < 42 else None)
                if exit_reason:
                    fill = price * (1 - SLIPPAGE_RATE)
                    proceeds = qty * fill * (1 - FEE_RATE)
                    pnl = proceeds - float(pos["cost_quote"])
                    if not PAPER:
                        order = ex.create_market_sell_order(SYMBOL, qty)
                        fill = float(order.get("average") or price)
                        proceeds = float(order.get("cost") or qty*fill) * (1-FEE_RATE)
                        pnl = proceeds - float(pos["cost_quote"])
                    state["daily_pnl"] += pnl
                    log.info("SELL %s qty=%.8f price=%.4f estimated_net_pnl=%.2f", exit_reason, qty, fill, pnl)
                    state["position"] = None
            elif state["daily_pnl"] > -abs(MAX_DAILY_LOSS_QUOTE):
                # Trend regime + breakout + momentum confirmation; avoids simple crossover-only entries.
                long_trend = float(r.close) > float(r.ema200) and float(r.ema50) > float(r.ema200)
                breakout = float(r.close) > float(r.prior_high)
                momentum = 52 <= float(r.rsi) <= 68 and float(r.plus_di) > float(r.minus_di) and float(r.adx) >= 18
                if long_trend and breakout and momentum and atr > 0:
                    stop_distance = 2.0 * atr
                    # Position sizing from risk budget, capped by quote notional.
                    risk_budget = MAX_DAILY_LOSS_QUOTE * min(max(RISK_FRACTION, 0.01), 0.50)
                    quote = min(QUOTE_PER_TRADE, MAX_POSITION_QUOTE, risk_budget * price / stop_distance)
                    if quote >= 10:
                        fill = price * (1 + SLIPPAGE_RATE)
                        qty = quote / fill
                        cost = quote * (1 + FEE_RATE)
                        if not PAPER:
                            if not API_KEY or not API_SECRET: raise RuntimeError("Live mode needs API credentials set on the server.")
                            if EXCHANGE_ID != "binance": raise RuntimeError("Live market-buy sizing is implemented for Binance only.")
                            order = ex.create_order(SYMBOL, "market", "buy", None, None, {"quoteOrderQty": str(quote)})
                            qty = float(order.get("filled") or 0)
                            fill = float(order.get("average") or price)
                            cost = float(order.get("cost") or quote) * (1 + FEE_RATE)
                        if qty > 0:
                            state["position"] = {"entry": fill, "qty": qty, "cost_quote": cost,
                                "stop": fill - stop_distance, "opened_at": now().isoformat()}
                            log.info("%s BUY quote=%.2f qty=%.8f entry=%.4f stop=%.4f RSI=%.1f ADX=%.1f",
                                "PAPER" if PAPER else "LIVE", quote, qty, fill, fill-stop_distance, float(r.rsi), float(r.adx))
            state["last_candle"] = candle_id
            save_state(state)
            log.info("price=%.4f RSI=%.1f ADX=%.1f daily_pnl=%.2f position=%s", price, float(r.rsi), float(r.adx), state["daily_pnl"], bool(state.get("position")))
        except Exception:
            log.exception("Loop error")
        time.sleep(POLL_SECONDS)

if __name__ == "__main__": main()
